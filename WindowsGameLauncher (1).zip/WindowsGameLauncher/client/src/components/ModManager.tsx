import { useState, useEffect } from 'react';
import { 
  installMod, 
  uninstallMod, 
  listInstalledMods, 
  ModInfo
} from '../lib/modManager';

interface ModManagerProps {
  onClose: () => void;
  gameInstallPath: string;
  setStatusMessage: (message: string) => void;
}

export default function ModManager({ 
  onClose, 
  gameInstallPath,
  setStatusMessage 
}: ModManagerProps) {
  const [mods, setMods] = useState<ModInfo[]>([]);
  const [selectedMod, setSelectedMod] = useState<ModInfo | null>(null);
  const [isInstalling, setIsInstalling] = useState<boolean>(false);
  const [isUninstalling, setIsUninstalling] = useState<boolean>(false);
  const [dragActive, setDragActive] = useState<boolean>(false);

  useEffect(() => {
    loadMods();
  }, [gameInstallPath]);

  const loadMods = async () => {
    try {
      const installedMods = await listInstalledMods(gameInstallPath);
      setMods(installedMods);
    } catch (error) {
      console.error('Failed to load mods:', error);
      setStatusMessage('Error loading mods');
    }
  };

  const handleModSelect = (mod: ModInfo) => {
    setSelectedMod(mod);
  };

  const handleInstallMod = async (files: FileList) => {
    if (!gameInstallPath) {
      setStatusMessage('Please set the game installation path first');
      return;
    }

    setIsInstalling(true);
    setStatusMessage('Installing mod...');

    try {
      const file = files[0]; // Get the first file
      
      // Check if it's a zip file
      if (!file.name.toLowerCase().endsWith('.zip')) {
        setStatusMessage('Only .zip mod files are supported');
        setIsInstalling(false);
        return;
      }
      
      await installMod(gameInstallPath, file);
      await loadMods(); // Refresh mod list
      setStatusMessage('Mod installed successfully');
    } catch (error) {
      console.error('Failed to install mod:', error);
      setStatusMessage('Error installing mod');
    } finally {
      setIsInstalling(false);
    }
  };

  const handleUninstallMod = async () => {
    if (!selectedMod) return;
    
    setIsUninstalling(true);
    setStatusMessage('Uninstalling mod...');
    
    try {
      await uninstallMod(gameInstallPath, selectedMod.name);
      await loadMods(); // Refresh mod list
      setSelectedMod(null);
      setStatusMessage('Mod uninstalled successfully');
    } catch (error) {
      console.error('Failed to uninstall mod:', error);
      setStatusMessage('Error uninstalling mod');
    } finally {
      setIsUninstalling(false);
    }
  };

  const handleModalContentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleInstallMod(e.dataTransfer.files);
    }
  };
  
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files.length > 0) {
      handleInstallMod(e.target.files);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 overflow-auto bg-black bg-opacity-60 flex items-center justify-center"
      onClick={onClose}
    >
      <div 
        className="modal relative w-full max-w-4xl mx-4 rounded-lg shadow-xl fade-in"
        onClick={handleModalContentClick}
      >
        <div className="bg-navy-dark border border-gold-dark rounded-lg">
          {/* Modal Header */}
          <div className="px-6 py-4 border-b border-gold-dark flex justify-between items-center">
            <h3 className="text-xl font-bold text-gold">Mod Manager</h3>
            <button 
              onClick={onClose}
              className="text-gray-400 hover:text-gold transition-colors"
              aria-label="Close"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          {/* Modal Body */}
          <div className="p-6">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Left Column - Mod List */}
              <div className="w-full md:w-1/3">
                <h4 className="text-lg font-bold mb-3 text-gold-light">Installed Mods</h4>
                <div className="bg-navy border border-gold-dark rounded-lg h-72 overflow-y-auto mb-4">
                  {mods.length === 0 ? (
                    <div className="p-4 text-gray-400 text-center">
                      No mods installed
                    </div>
                  ) : (
                    <div className="p-1">
                      {mods.map((mod, index) => (
                        <div 
                          key={index}
                          className={`p-3 m-2 rounded cursor-pointer transition-colors ${selectedMod?.name === mod.name ? 'bg-navy-light border border-gold' : 'bg-navy-light bg-opacity-40 hover:bg-navy-light'}`}
                          onClick={() => handleModSelect(mod)}
                        >
                          <h5 className="font-bold text-gold-light">{mod.name}</h5>
                          <p className="text-sm text-gray-300">v{mod.version}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              
              {/* Right Column - Mod Details & Upload */}
              <div className="w-full md:w-2/3">
                {/* Mod Details Section */}
                {selectedMod ? (
                  <div className="bg-navy-light bg-opacity-40 rounded-lg p-4 mb-6">
                    <div className="flex justify-between items-start mb-4">
                      <h4 className="text-lg font-bold text-gold">{selectedMod.name}</h4>
                      <span className="bg-gold text-navy-dark text-xs px-2 py-1 rounded">v{selectedMod.version}</span>
                    </div>
                    
                    <div className="space-y-3 mb-4">
                      <p className="text-gray-300">{selectedMod.description}</p>
                      
                      <div className="flex flex-wrap gap-4 text-sm">
                        <div>
                          <span className="text-gray-400">Author: </span>
                          <span className="text-white">{selectedMod.author}</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Year: </span>
                          <span className="text-white">{selectedMod.year}</span>
                        </div>
                      </div>
                      
                      {selectedMod.website && (
                        <a 
                          href={selectedMod.website} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="inline-block text-gold hover:text-gold-light underline text-sm"
                        >
                          Visit Website
                        </a>
                      )}
                    </div>
                    
                    <button 
                      onClick={handleUninstallMod}
                      disabled={isUninstalling}
                      className="bg-red-700 hover:bg-red-800 text-white px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isUninstalling ? 'Uninstalling...' : 'Uninstall Mod'}
                    </button>
                  </div>
                ) : (
                  <div className="bg-navy-light bg-opacity-40 rounded-lg p-4 mb-6 text-center">
                    <p className="text-gray-400">Select a mod to view details</p>
                  </div>
                )}
                
                {/* Upload Section */}
                <div 
                  className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${dragActive ? 'border-gold bg-navy-light bg-opacity-40' : 'border-gray-600'}`}
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                >
                  <div className="flex flex-col items-center justify-center py-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    
                    <h5 className="text-lg font-bold text-gold-light mb-2">Install New Mod</h5>
                    <p className="text-gray-400 text-sm mb-4">Drag and drop mod .zip file here, or click to browse</p>
                    
                    <label className="relative">
                      <input
                        type="file"
                        accept=".zip"
                        onChange={handleFileInput}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        disabled={isInstalling}
                      />
                      <div className="bg-gold hover:bg-gold-light text-navy-dark font-bold px-4 py-2 rounded glow-button transition-colors focus:outline-none focus:ring-2 focus:ring-gold disabled:opacity-50 disabled:cursor-not-allowed">
                        {isInstalling ? 'Installing...' : 'Browse Mod Files'}
                      </div>
                    </label>
                  </div>
                </div>
                
                {/* Installation Note */}
                <div className="mt-4 text-sm text-gray-400">
                  <p>Note: Mod files will be extracted directly to the game installation directory. Any existing files will be overwritten.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}