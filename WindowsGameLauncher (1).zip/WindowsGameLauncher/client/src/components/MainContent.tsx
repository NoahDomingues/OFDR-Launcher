import { useCallback } from 'react';
import { launchGame, launchMissionEditor, openModsFolder } from '@/lib/electron';

interface MainContentProps {
  isFirstRun: boolean;
  gameInstallPath: string;
  onBrowse: () => void;
  onSavePath: () => void;
  setStatusMessage: (message: string) => void;
  onOpenModManager: () => void;
}

export default function MainContent({ 
  isFirstRun, 
  gameInstallPath, 
  onBrowse, 
  onSavePath,
  setStatusMessage,
  onOpenModManager
}: MainContentProps) {
  
  const handlePlay = useCallback(() => {
    setStatusMessage('Launching game...');
    launchGame(gameInstallPath);
    
    // Reset status message after a delay
    setTimeout(() => {
      setStatusMessage('Ready to launch');
    }, 3000);
  }, [gameInstallPath, setStatusMessage]);
  
  const handleMissionEditor = useCallback(() => {
    setStatusMessage('Launching Mission Editor...');
    launchMissionEditor(gameInstallPath);
    
    // Reset status message after a delay
    setTimeout(() => {
      setStatusMessage('Ready to launch');
    }, 3000);
  }, [gameInstallPath, setStatusMessage]);
  
  const handleMods = useCallback(() => {
    setStatusMessage('Opening Mod Manager...');
    onOpenModManager();
    
    // Reset status message after a delay
    setTimeout(() => {
      setStatusMessage('Ready to launch');
    }, 3000);
  }, [onOpenModManager, setStatusMessage]);

  return (
    <main className="flex flex-col items-center justify-center h-[calc(100vh-180px)]">
      <div className="w-full max-w-3xl px-6">
        {/* Game path message (when set) */}
        {!isFirstRun && (
          <div className="bg-navy-light bg-opacity-70 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gold mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span>Game installed at: {gameInstallPath}</span>
            </div>
          </div>
        )}
        
        {/* First-run game directory prompt */}
        {isFirstRun && (
          <div className="bg-navy-light bg-opacity-70 rounded-lg p-6 border border-gold-dark">
            <h2 className="text-xl font-bold mb-4">Welcome to Operation Flashpoint: Dragon Rising Launcher</h2>
            <p className="mb-6 text-gray-300">Please locate your game installation directory to continue.</p>
            
            <div className="flex items-center space-x-2 mb-6">
              <input 
                type="text" 
                className="flex-grow bg-navy-dark border border-gold-dark text-white px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-gold-light" 
                placeholder="Game installation path..." 
                readOnly 
                value={gameInstallPath}
              />
              <button 
                onClick={onBrowse}
                className="bg-gold hover:bg-gold-light text-navy-dark font-bold px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-gold transition-colors"
              >
                Browse
              </button>
            </div>
            
            <button 
              onClick={onSavePath}
              disabled={!gameInstallPath}
              className="w-full bg-gold hover:bg-gold-light text-navy-dark font-bold py-3 rounded glow-button transition-colors focus:outline-none focus:ring-2 focus:ring-gold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Save Path
            </button>
          </div>
        )}
        
        {/* Main launcher buttons */}
        {!isFirstRun && (
          <div className="mt-12">
            <div className="grid grid-cols-1 gap-4">
              <button 
                onClick={handlePlay}
                className="bg-gold hover:bg-gold-light text-navy-dark text-xl font-bold py-4 rounded-lg glow-button tracking-wider transition-colors flex justify-center items-center space-x-2 focus:outline-none focus:ring-2 focus:ring-gold"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>PLAY</span>
              </button>
              
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={handleMissionEditor}
                  className="bg-navy-light hover:bg-navy border border-gold-dark text-gold hover:text-gold-light text-lg font-bold py-3 rounded-lg glow-button tracking-wider transition-colors flex justify-center items-center space-x-2 focus:outline-none focus:ring-2 focus:ring-gold-dark"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  <span>MISSION EDITOR</span>
                </button>
                
                <button 
                  onClick={handleMods}
                  className="bg-navy-light hover:bg-navy border border-gold-dark text-gold hover:text-gold-light text-lg font-bold py-3 rounded-lg glow-button tracking-wider transition-colors flex justify-center items-center space-x-2 focus:outline-none focus:ring-2 focus:ring-gold-dark"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                  </svg>
                  <span>MODS</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
