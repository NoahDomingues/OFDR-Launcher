import { useState, useEffect } from 'react';
import { listDirectories } from '@/lib/electron';

interface DirectoryModalProps {
  onClose: () => void;
  onConfirm: () => void;
  onSelectDirectory: (path: string) => void;
  selectedPath: string;
}

interface DirectoryItem {
  name: string;
  path: string;
  isSelected: boolean;
}

export default function DirectoryModal({ 
  onClose, 
  onConfirm, 
  onSelectDirectory,
  selectedPath 
}: DirectoryModalProps) {
  const [directories, setDirectories] = useState<DirectoryItem[]>([]);
  
  useEffect(() => {
    // In actual implementation, this would use Electron to list actual directories
    const fetchDirectories = async () => {
      try {
        const dirs = await listDirectories(selectedPath || 'C:\\');
        setDirectories(dirs.map(dir => ({
          name: dir.name,
          path: dir.path,
          isSelected: dir.path === selectedPath
        })));
      } catch (error) {
        console.error('Failed to list directories:', error);
        // Fallback to some common game locations
        setDirectories([
          { name: 'C:\\Games', path: 'C:\\Games', isSelected: selectedPath === 'C:\\Games' },
          { name: 'Operation Flashpoint Dragon Rising', path: 'C:\\Games\\Operation Flashpoint Dragon Rising', isSelected: selectedPath === 'C:\\Games\\Operation Flashpoint Dragon Rising' },
          { name: 'Steam\\steamapps\\common', path: 'C:\\Program Files (x86)\\Steam\\steamapps\\common', isSelected: selectedPath === 'C:\\Program Files (x86)\\Steam\\steamapps\\common' },
        ]);
      }
    };
    
    fetchDirectories();
  }, [selectedPath]);

  const handleSelectDirectory = (path: string) => {
    onSelectDirectory(path);
    setDirectories(directories.map(dir => ({
      ...dir,
      isSelected: dir.path === path
    })));
  };

  const handleModalContentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div 
      className="fixed inset-0 z-50 overflow-auto bg-black bg-opacity-60 flex items-center justify-center"
      onClick={onClose}
    >
      <div 
        className="modal relative w-full max-w-lg mx-4 rounded-lg shadow-xl fade-in"
        onClick={handleModalContentClick}
      >
        <div className="bg-navy-dark border border-gold-dark rounded-lg">
          {/* Modal Header */}
          <div className="px-6 py-4 border-b border-gold-dark flex justify-between items-center">
            <h3 className="text-xl font-bold text-gold">Select Game Directory</h3>
            <button 
              onClick={onClose}
              className="text-gray-400 hover:text-gold transition-colors"
              aria-label="Close"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          {/* Modal Body */}
          <div className="px-6 py-4">
            {/* Directory Explorer */}
            <div className="bg-navy border border-gold-dark rounded-lg h-64 overflow-y-auto mb-4">
              <div className="p-3">
                {directories.map((dir, index) => (
                  <div 
                    key={index}
                    className={`flex items-center mb-2 hover:bg-navy-light p-2 rounded cursor-pointer ${dir.isSelected ? 'bg-navy-light' : ''}`}
                    onClick={() => handleSelectDirectory(dir.path)}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gold mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                    </svg>
                    <span>{dir.name}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Selected Path */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-400 mb-1">Selected Path:</label>
              <input 
                type="text" 
                className="w-full bg-navy border border-gold-dark text-white px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-gold-light" 
                readOnly 
                value={selectedPath}
              />
            </div>
            
            {/* Action Buttons */}
            <div className="flex justify-end space-x-3">
              <button 
                onClick={onClose}
                className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-gray-500 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={onConfirm}
                className="bg-gold hover:bg-gold-light text-navy-dark font-bold py-2 px-4 rounded glow-button focus:outline-none focus:ring-2 focus:ring-gold transition-colors"
              >
                Select Directory
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
