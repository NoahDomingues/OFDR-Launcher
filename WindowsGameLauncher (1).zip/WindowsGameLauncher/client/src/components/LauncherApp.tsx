import { useState, useEffect } from 'react';
import Header from './Header';
import MainContent from './MainContent';
import Footer from './Footer';
import SettingsModal from './SettingsModal';
import DirectoryModal from './DirectoryModal';
import ModManager from './ModManager';
import MapBackground from './MapBackground';
import { getGamePath, saveGamePath } from '@/lib/gameConfig';

export default function LauncherApp() {
  const [isFirstRun, setIsFirstRun] = useState(true);
  const [gameInstallPath, setGameInstallPath] = useState<string>('');
  const [isDirectoryModalOpen, setIsDirectoryModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isModManagerOpen, setIsModManagerOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string>('Ready to launch');
  const [tempPath, setTempPath] = useState<string>('');
  const [directorySource, setDirectorySource] = useState<'settings' | 'setup'>('setup');

  useEffect(() => {
    const path = getGamePath();
    if (path) {
      setGameInstallPath(path);
      setIsFirstRun(false);
    }
  }, []);

  const handleOpenSettings = () => {
    setIsSettingsModalOpen(true);
  };

  const handleCloseSettings = () => {
    setIsSettingsModalOpen(false);
  };
  
  const handleOpenModManager = () => {
    setIsModManagerOpen(true);
  };
  
  const handleCloseModManager = () => {
    setIsModManagerOpen(false);
  };

  const handleBrowse = (source: 'settings' | 'setup') => {
    setDirectorySource(source);
    setIsDirectoryModalOpen(true);
  };

  const handleCloseDirectory = () => {
    setIsDirectoryModalOpen(false);
  };

  const handleSelectDirectory = (path: string) => {
    setTempPath(path);
  };

  const handleConfirmDirectory = () => {
    if (tempPath) {
      if (directorySource === 'setup') {
        setGameInstallPath(tempPath);
      } else {
        setGameInstallPath(tempPath);
        saveGamePath(tempPath);
        setStatusMessage('Game directory updated. Ready to launch.');
        setTimeout(() => {
          setStatusMessage('Ready to launch');
        }, 3000);
      }
    }
    setIsDirectoryModalOpen(false);
  };

  const handleSavePath = () => {
    if (gameInstallPath) {
      saveGamePath(gameInstallPath);
      setIsFirstRun(false);
      setStatusMessage('Game directory saved. Ready to launch.');
      setTimeout(() => {
        setStatusMessage('Ready to launch');
      }, 3000);
    }
  };

  return (
    <div className="text-white min-h-screen flex flex-col">
      <MapBackground />
      
      <Header onOpenSettings={handleOpenSettings} />
      
      <MainContent 
        isFirstRun={isFirstRun}
        gameInstallPath={gameInstallPath}
        onBrowse={() => handleBrowse('setup')}
        onSavePath={handleSavePath}
        setStatusMessage={setStatusMessage}
        onOpenModManager={handleOpenModManager}
      />
      
      <Footer statusMessage={statusMessage} />
      
      {isSettingsModalOpen && (
        <SettingsModal 
          onClose={handleCloseSettings}
          gameInstallPath={gameInstallPath}
          onBrowse={() => handleBrowse('settings')}
        />
      )}
      
      {isDirectoryModalOpen && (
        <DirectoryModal
          onClose={handleCloseDirectory}
          onConfirm={handleConfirmDirectory}
          onSelectDirectory={handleSelectDirectory}
          selectedPath={tempPath || gameInstallPath}
        />
      )}
      
      {isModManagerOpen && (
        <ModManager
          onClose={handleCloseModManager}
          gameInstallPath={gameInstallPath}
          setStatusMessage={setStatusMessage}
        />
      )}
    </div>
  );
}
