interface FooterProps {
  statusMessage: string;
}

export default function Footer({ statusMessage }: FooterProps) {
  return (
    <footer className="absolute bottom-0 w-full px-8 py-4 flex justify-between items-center">
      <a 
        href="https://discord.gg/Z88NnTgpWU" 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-gray-400 hover:text-gold text-sm transition-colors"
      >
        Join us on Discord
      </a>
      
      <div className="text-gray-400 text-sm animate-pulse-slow">
        {statusMessage}
      </div>
    </footer>
  );
}
