import { getGamePath as electronGetGamePath, saveGamePath as electronSaveGamePath } from './electron';

/**
 * Save the game installation path
 */
export const saveGamePath = (path: string): void => {
  electronSaveGamePath(path);
};

/**
 * Get the saved game installation path
 */
export const getGamePath = (): string => {
  return electronGetGamePath();
};

/**
 * Check if the game executable exists at the specified path
 */
export const validateGamePath = (path: string): boolean => {
  if (!path) return false;
  
  // In a real implementation, we would use Electron's fs module to check if OFDR.exe exists
  // For now, we'll assume all paths are valid if they're not empty
  
  return true;
};

/**
 * Get mods directory path
 */
export const getModsPath = (gamePath: string): string => {
  if (!gamePath) return '';
  return `${gamePath}\\Mods`;
};

/**
 * Get mission editor path
 */
export const getMissionEditorPath = (gamePath: string): string => {
  if (!gamePath) return '';
  return `${gamePath}\\MissionEditor.exe`;
};

/**
 * Get game executable path
 */
export const getGameExecutablePath = (gamePath: string): string => {
  if (!gamePath) return '';
  return `${gamePath}\\OFDR.exe`;
};
