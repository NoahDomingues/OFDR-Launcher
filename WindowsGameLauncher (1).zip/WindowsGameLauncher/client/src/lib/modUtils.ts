import fs from 'fs';
import path from 'path';
import os from 'os';
import { ModInfo, parseModInfo } from './modManager';

/**
 * Create a temporary directory for mod extraction
 */
export const createTempDir = (): string => {
  const tempDir = path.join(os.tmpdir(), `ofdr-mod-${Date.now()}`);
  fs.mkdirSync(tempDir, { recursive: true });
  return tempDir;
};

/**
 * Read and parse a mod.inf file
 */
export const readModInf = (modInfPath: string): ModInfo => {
  const contents = fs.readFileSync(modInfPath, 'utf-8');
  return parseModInfo(contents);
};

/**
 * Copy files recursively from source to destination
 */
export const copyFilesRecursively = (source: string, destination: string): void => {
  // Ensure destination directory exists
  fs.mkdirSync(destination, { recursive: true });

  // Get all items in the source directory
  const items = fs.readdirSync(source);

  for (const item of items) {
    // Skip the mod.inf file - we don't want to copy it to the game directory
    if (item === 'mod.inf') continue;

    const sourcePath = path.join(source, item);
    const destPath = path.join(destination, item);

    const stat = fs.statSync(sourcePath);

    if (stat.isDirectory()) {
      // Recursively copy subdirectories
      copyFilesRecursively(sourcePath, destPath);
    } else {
      // Copy file
      fs.copyFileSync(sourcePath, destPath);
    }
  }
};

/**
 * Create a sample mod.inf file
 */
export const createSampleModInf = (outputPath: string, modInfo: Partial<ModInfo>): void => {
  const defaultInfo: ModInfo = {
    name: 'Sample Mod',
    description: 'This is a sample mod for Operation Flashpoint: Dragon Rising.',
    author: 'Your Name',
    version: '1.0.0',
    year: new Date().getFullYear().toString(),
    website: 'https://example.com'
  };

  const info = { ...defaultInfo, ...modInfo };
  
  const content = `name=${info.name}
description=${info.description}
author=${info.author}
version=${info.version}
year=${info.year}
website=${info.website || ''}
`;

  fs.writeFileSync(outputPath, content, 'utf-8');
};