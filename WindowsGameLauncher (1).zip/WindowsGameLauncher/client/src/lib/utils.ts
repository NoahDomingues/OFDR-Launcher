import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
 
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPath(path: string): string {
  // Ensure consistent path format for display
  return path.replace(/\\/g, '\\');
}

export function isValidPath(path: string): boolean {
  // Basic path validation
  if (!path || path.trim() === '') return false;
  
  // Windows path validation rules
  const invalidChars = /[<>:"|?*]/;
  if (invalidChars.test(path)) return false;
  
  // Check for valid drive letter format
  const driveLetterPattern = /^[a-zA-Z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*$/;
  return driveLetterPattern.test(path);
}
