import path from 'path';
import { getModsPath } from './gameConfig';

// Define the ModInfo interface based on mod.inf structure
export interface ModInfo {
  name: string;
  description: string;
  author: string;
  version: string;
  year: string;
  website?: string;
}

/**
 * Install a mod from a zip file
 */
export const installMod = async (gamePath: string, modFile: File): Promise<void> => {
  if (window.api && window.api.installMod) {
    try {
      // In a real implementation, this would use Electron to:
      // 1. Extract the zip file to a temp directory
      // 2. Read mod.inf to get mod info
      // 3. Extract the contents to the game directory
      // 4. Store mod info for future reference
      
      // Create a FileReader to read the file as an ArrayBuffer
      const reader = new FileReader();
      const filePromise = new Promise<ArrayBuffer>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as ArrayBuffer);
        reader.onerror = reject;
        reader.readAsArrayBuffer(modFile);
      });
      
      const buffer = await filePromise;
      await window.api.installMod(gamePath, buffer, modFile.name);
      return Promise.resolve();
    } catch (error) {
      console.error('Error installing mod:', error);
      return Promise.reject(error);
    }
  } else {
    console.warn('Electron API not available. Cannot install mod in browser mode.');
    // Simulate successful installation for demo purposes
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate delay
    return Promise.resolve();
  }
};

/**
 * Uninstall a mod by name
 */
export const uninstallMod = async (gamePath: string, modName: string): Promise<void> => {
  if (window.api && window.api.uninstallMod) {
    try {
      await window.api.uninstallMod(gamePath, modName);
      return Promise.resolve();
    } catch (error) {
      console.error('Error uninstalling mod:', error);
      return Promise.reject(error);
    }
  } else {
    console.warn('Electron API not available. Cannot uninstall mod in browser mode.');
    // Simulate successful uninstallation for demo purposes
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate delay
    return Promise.resolve();
  }
};

/**
 * List all installed mods
 */
export const listInstalledMods = async (gamePath: string): Promise<ModInfo[]> => {
  if (window.api && window.api.listInstalledMods) {
    try {
      return await window.api.listInstalledMods(gamePath);
    } catch (error) {
      console.error('Error listing installed mods:', error);
      return [];
    }
  } else {
    console.warn('Electron API not available. Cannot list mods in browser mode.');
    // Return mock mods for browser mode
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate delay
    
    // Sample mods for demonstration
    return [
      {
        name: 'Enhanced Visuals',
        description: 'Improves game graphics with high-resolution textures and enhanced lighting effects.',
        author: 'ModTeam Studios',
        version: '2.1.0',
        year: '2023',
        website: 'https://example.com/enhanced-visuals'
      },
      {
        name: 'Realistic Combat',
        description: 'Overhauls the combat system for a more realistic and challenging experience.',
        author: 'TacticalMods',
        version: '1.5',
        year: '2022',
        website: 'https://example.com/realistic-combat'
      },
      {
        name: 'New Weapons Pack',
        description: 'Adds 25 new weapons to the game with custom models and sounds.',
        author: 'WeaponsMaster',
        version: '3.0',
        year: '2024'
      }
    ];
  }
};

/**
 * Parse a mod.inf file to extract mod information
 */
export const parseModInfo = (modInfContents: string): ModInfo => {
  const lines = modInfContents.split('\n');
  const info: Partial<ModInfo> = {};
  
  for (const line of lines) {
    const [key, value] = line.split('=').map(part => part.trim());
    
    if (key && value) {
      switch (key.toLowerCase()) {
        case 'name':
          info.name = value;
          break;
        case 'description':
          info.description = value;
          break;
        case 'author':
          info.author = value;
          break;
        case 'version':
          info.version = value;
          break;
        case 'year':
          info.year = value;
          break;
        case 'website':
          info.website = value;
          break;
      }
    }
  }
  
  // Set default values for missing fields
  return {
    name: info.name || 'Unknown Mod',
    description: info.description || 'No description provided.',
    author: info.author || 'Unknown',
    version: info.version || '1.0',
    year: info.year || new Date().getFullYear().toString(),
    website: info.website
  };
};

// Update the global Window interface to include our new mod operations
declare global {
  interface Window {
    api?: {
      saveGamePath: (path: string) => void;
      getGamePath: () => string;
      launchGame: (path: string) => void;
      launchMissionEditor: (path: string) => void;
      openModsFolder: (path: string) => void;
      listDirectories: (path: string) => Promise<{ name: string; path: string }[]>;
      installMod?: (gamePath: string, modBuffer: ArrayBuffer, fileName: string) => Promise<void>;
      uninstallMod?: (gamePath: string, modName: string) => Promise<void>;
      listInstalledMods?: (gamePath: string) => Promise<ModInfo[]>;
    };
  }
}