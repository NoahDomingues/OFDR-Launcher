// This file provides an interface to Electron features through the contextBridge
// In a real implementation, we would use the window.api methods exposed by the preload script

/**
 * Save game path to configuration
 */
export const saveGamePath = (path: string): void => {
  if (window.api) {
    window.api.saveGamePath(path);
  } else {
    console.warn('Electron API not available. Running in browser mode.');
    localStorage.setItem('gameInstallPath', path);
  }
};

/**
 * Get saved game path from configuration
 */
export const getGamePath = (): string => {
  if (window.api) {
    return window.api.getGamePath();
  } else {
    console.warn('Electron API not available. Running in browser mode.');
    return localStorage.getItem('gameInstallPath') || '';
  }
};

/**
 * Launch the game executable
 */
export const launchGame = (gamePath: string): void => {
  if (window.api) {
    window.api.launchGame(gamePath);
  } else {
    console.warn('Electron API not available. Cannot launch game in browser mode.');
    console.log('Would launch game at:', `${gamePath}\\OFDR.exe`);
  }
};

/**
 * Launch the mission editor
 */
export const launchMissionEditor = (gamePath: string): void => {
  if (window.api) {
    window.api.launchMissionEditor(gamePath);
  } else {
    console.warn('Electron API not available. Cannot launch mission editor in browser mode.');
    console.log('Would launch mission editor at:', `${gamePath}\\MissionEditor.exe`);
  }
};

/**
 * Open the mods folder
 */
export const openModsFolder = (gamePath: string): void => {
  if (window.api) {
    window.api.openModsFolder(gamePath);
  } else {
    console.warn('Electron API not available. Cannot open mods folder in browser mode.');
    console.log('Would open mods folder at:', `${gamePath}\\Mods`);
  }
};

/**
 * List directories for directory browser
 */
export const listDirectories = async (path: string): Promise<{ name: string; path: string }[]> => {
  if (window.api) {
    return window.api.listDirectories(path);
  } else {
    console.warn('Electron API not available. Cannot list directories in browser mode.');
    // Return mock directories for browser mode
    return [
      { name: 'C:\\Games', path: 'C:\\Games' },
      { name: 'Operation Flashpoint Dragon Rising', path: 'C:\\Games\\Operation Flashpoint Dragon Rising' },
      { name: 'Steam\\steamapps\\common', path: 'C:\\Program Files (x86)\\Steam\\steamapps\\common' },
    ];
  }
};

// Type definitions for the window.api object
declare global {
  interface Window {
    api?: {
      saveGamePath: (path: string) => void;
      getGamePath: () => string;
      launchGame: (path: string) => void;
      launchMissionEditor: (path: string) => void;
      openModsFolder: (path: string) => void;
      listDirectories: (path: string) => Promise<{ name: string; path: string }[]>;
      installMod?: (gamePath: string, modBuffer: ArrayBuffer, fileName: string) => Promise<void>;
      uninstallMod?: (gamePath: string, modName: string) => Promise<void>;
      listInstalledMods?: (gamePath: string) => Promise<any[]>;
    };
  }
}
