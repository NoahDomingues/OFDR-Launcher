import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the launcher
  app.get('/api/check-game-path', (req, res) => {
    const { path } = req.query;
    
    if (!path) {
      return res.status(400).json({ error: 'No path provided' });
    }
    
    // In a real implementation, we would check if OFDR.exe exists
    // For this example, we'll just return success
    res.json({ valid: true });
  });

  const httpServer = createServer(app);
  return httpServer;
}
