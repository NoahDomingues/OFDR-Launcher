const { app, BrowserWindow, ipcMain, shell, protocol } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const Store = require('electron-store');
const AdmZip = require('adm-zip');
const { registerProtocols, registerFileProtocolHandler } = require('./setUrlScheme');

// Force CommonJS for all modules loaded in the main process
process.env.NODE_OPTIONS = '--openssl-legacy-provider --no-experimental-modules';

// Disable ESM URL scheme errors and use commonjs for all modules
app.allowRendererProcessReuse = false;

// Register protocol schemes as privileged before app is ready
registerProtocols();

// Initialize store for app settings
const store = new Store();

// Keep a global reference of the window object
let mainWindow;

function createWindow() {
  // Create the browser window
  mainWindow = new BrowserWindow({
    width: 1024,
    height: 768,
    minWidth: 800,
    minHeight: 600,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      // Add these settings to ensure CommonJS modules work correctly
      nodeIntegrationInWorker: false,
      nodeIntegrationInSubFrames: false,
      enableRemoteModule: false,
      worldSafeExecuteJavaScript: true,
      webSecurity: true
    },
    icon: path.join(__dirname, 'attached_assets/OFDRLauncher_01_1746787566569.jpg'),
    frame: true,
    resizable: true,
    backgroundColor: '#0A192F',
    show: false,
  });

  // Load the app
  if (app.isPackaged) {
    // In production, load the built files
    mainWindow.loadFile(path.join(__dirname, 'dist/public/index.html'));
  } else {
    // In development, load from the dev server
    const port = process.env.PORT || 5000;
    mainWindow.loadURL(`http://localhost:${port}`);
    
    // Open the DevTools in development
    mainWindow.webContents.openDevTools();
  }

  // Show the window when it's ready
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Emitted when the window is closed
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Create window when Electron has finished initialization
app.whenReady().then(() => {
  // Register file protocol handler to fix ESM URL scheme errors
  registerFileProtocolHandler(protocol);
  
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// Quit when all windows are closed
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Handle IPC events from renderer process

// Save game path
ipcMain.on('save-game-path', (event, gamePath) => {
  store.set('gamePath', gamePath);
});

// Get game path
ipcMain.on('get-game-path', (event) => {
  event.returnValue = store.get('gamePath', '');
});

// Launch game
ipcMain.on('launch-game', (event, gamePath) => {
  const executablePath = path.join(gamePath, 'OFDR.exe');
  
  try {
    if (fs.existsSync(executablePath)) {
      spawn(executablePath, [], { detached: true, stdio: 'ignore' }).unref();
    } else {
      // Notify user if executable not found
      event.reply('game-launch-error', 'Game executable not found.');
    }
  } catch (error) {
    console.error('Error launching game:', error);
    event.reply('game-launch-error', error.message);
  }
});

// Launch mission editor
ipcMain.on('launch-mission-editor', (event, gamePath) => {
  const missionEditorPath = path.join(gamePath, 'MissionEditor.exe');
  
  try {
    if (fs.existsSync(missionEditorPath)) {
      spawn(missionEditorPath, [], { detached: true, stdio: 'ignore' }).unref();
    } else {
      // Notify user if mission editor not found
      event.reply('mission-editor-error', 'Mission editor not found.');
    }
  } catch (error) {
    console.error('Error launching mission editor:', error);
    event.reply('mission-editor-error', error.message);
  }
});

// Open mods folder
ipcMain.on('open-mods-folder', (event, gamePath) => {
  const modsPath = path.join(gamePath, 'Mods');
  
  try {
    // Create mods directory if it doesn't exist
    if (!fs.existsSync(modsPath)) {
      fs.mkdirSync(modsPath, { recursive: true });
    }
    
    // Open mods folder
    shell.openPath(modsPath);
  } catch (error) {
    console.error('Error opening mods folder:', error);
    event.reply('mods-folder-error', error.message);
  }
});

// List directories
ipcMain.handle('list-directories', async (event, directoryPath) => {
  try {
    // If path doesn't exist, default to C:\ or home directory
    if (!fs.existsSync(directoryPath)) {
      directoryPath = process.platform === 'win32' ? 'C:\\' : require('os').homedir();
    }
    
    const files = await fs.promises.readdir(directoryPath, { withFileTypes: true });
    const directories = files
      .filter(file => file.isDirectory())
      .map(dir => {
        const fullPath = path.join(directoryPath, dir.name);
        return {
          name: dir.name,
          path: fullPath
        };
      });
    
    // Add parent directory option if not at root
    if (directoryPath !== 'C:\\' && directoryPath !== '/') {
      const parentPath = path.dirname(directoryPath);
      directories.unshift({
        name: '..',
        path: parentPath
      });
    }
    
    return directories;
  } catch (error) {
    console.error('Error listing directories:', error);
    return [];
  }
});

// Install a mod
ipcMain.handle('install-mod', async (event, gamePath, modBuffer, fileName) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const os = require('os');
    const AdmZip = require('adm-zip');
    
    console.log(`Installing mod from buffer with filename: ${fileName} to game at: ${gamePath}`);
    
    // 1. Create a temporary directory for extraction
    const tempDir = path.join(os.tmpdir(), 'ofdr-mods', Date.now().toString());
    fs.mkdirSync(tempDir, { recursive: true });
    
    // Write the buffer to a temporary file
    const tempFilePath = path.join(tempDir, fileName);
    fs.writeFileSync(tempFilePath, Buffer.from(modBuffer));
    
    // 2. Extract the zip file to the temp directory
    const zip = new AdmZip(tempFilePath);
    const extractDir = path.join(tempDir, 'extracted');
    fs.mkdirSync(extractDir, { recursive: true });
    zip.extractAllTo(extractDir, true);
    
    // 3. Look for mod.inf file
    const modInfPath = path.join(extractDir, 'mod.inf');
    if (!fs.existsSync(modInfPath)) {
      throw new Error('Invalid mod: mod.inf file not found');
    }
    
    // 4. Read and parse mod.inf file
    const modInfContent = fs.readFileSync(modInfPath, 'utf8');
    
    // Parse mod.inf file
    const modInfo = parseModInfo(modInfContent);
    
    // 5. Copy all files to the game directory
    // This is a simplified version. In a real implementation, you'd recursively copy all files
    copyDir(extractDir, gamePath);
    
    // 6. Store mod info in the app's storage
    const modsDb = store.get('installedMods', []);
    modsDb.push(modInfo);
    store.set('installedMods', modsDb);
    
    console.log(`Successfully installed mod: ${modInfo.name}`);
    return { success: true };
  } catch (error) {
    console.error('Error installing mod:', error);
    throw error;
  }
});

// Helper function to parse mod.inf file
function parseModInfo(modInfContents) {
  const lines = modInfContents.split('\n');
  const info = {};
  
  for (const line of lines) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      const key = parts[0].trim().toLowerCase();
      const value = parts.slice(1).join('=').trim();
      
      switch (key) {
        case 'name':
          info.name = value;
          break;
        case 'description':
          info.description = value;
          break;
        case 'author':
          info.author = value;
          break;
        case 'version':
          info.version = value;
          break;
        case 'year':
          info.year = value;
          break;
        case 'website':
          info.website = value;
          break;
      }
    }
  }
  
  // Set default values for missing fields
  return {
    name: info.name || 'Unknown Mod',
    description: info.description || 'No description provided.',
    author: info.author || 'Unknown',
    version: info.version || '1.0',
    year: info.year || new Date().getFullYear().toString(),
    website: info.website
  };
}

// Helper function to recursively copy directories
function copyDir(src, dest) {
  const fs = require('fs');
  const path = require('path');
  
  // Create destination directory if it doesn't exist
  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }
  
  // Read source directory contents
  const entries = fs.readdirSync(src, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      // Recursively copy subdirectories
      copyDir(srcPath, destPath);
    } else {
      // Copy files
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

// Uninstall a mod
ipcMain.handle('uninstall-mod', async (event, gamePath, modName) => {
  try {
    console.log(`Uninstalling mod: ${modName} from game at: ${gamePath}`);
    
    // 1. Get the list of installed mods
    const modsDb = store.get('installedMods', []);
    
    // 2. Find the mod to uninstall
    const modIndex = modsDb.findIndex(mod => mod.name === modName);
    if (modIndex === -1) {
      throw new Error(`Mod "${modName}" not found`);
    }
    
    // 3. Remove the mod from the database
    const removedMod = modsDb.splice(modIndex, 1)[0];
    store.set('installedMods', modsDb);
    
    console.log(`Successfully uninstalled mod: ${removedMod.name}`);
    return { success: true };
  } catch (error) {
    console.error('Error uninstalling mod:', error);
    throw error;
  }
});

// List installed mods
ipcMain.handle('list-installed-mods', async (event, gamePath) => {
  try {
    console.log(`Listing installed mods for game at: ${gamePath}`);
    
    // Get the list of installed mods from storage
    const modsDb = store.get('installedMods', []);
    return modsDb;
  } catch (error) {
    console.error('Error listing installed mods:', error);
    return [];
  }
});
