const { protocol } = require('electron');
const path = require('path');
const url = require('url');
const fs = require('fs');

/**
 * Register custom protocol handlers to fix ESM URL scheme issues
 */
function registerProtocols() {
  // Register privileged schemes before app is ready (must be done before app.ready)
  protocol.registerSchemesAsPrivileged([
    { scheme: 'file', privileges: { standard: true, supportFetchAPI: true, secure: true, bypassCSP: true, allowServiceWorkers: true, corsEnabled: true } },
    { scheme: 'electron', privileges: { standard: true, supportFetchAPI: true, secure: true, bypassCSP: true, allowServiceWorkers: true, corsEnabled: true } }
  ]);
}

/**
 * Register file protocol handler (must be called after app.ready)
 */
function registerFileProtocolHandler(protocol) {
  protocol.registerFileProtocol('file', (request, callback) => {
    try {
      // Convert file:// URLs to paths
      let filePath = request.url;
      
      // Remove the 'file://' prefix
      if (filePath.startsWith('file://')) {
        filePath = filePath.substr(process.platform === 'win32' ? 8 : 7);
      }
      
      // Decode URI components and normalize the path
      filePath = decodeURIComponent(filePath);
      
      // Fix Windows paths
      if (process.platform === 'win32' && filePath.startsWith('/')) {
        filePath = filePath.substring(1);
      }
      
      callback({ path: path.normalize(filePath) });
    } catch (error) {
      console.error('Protocol handler error:', error);
      callback({ error });
    }
  });
}

module.exports = {
  registerProtocols,
  registerFileProtocolHandler
};