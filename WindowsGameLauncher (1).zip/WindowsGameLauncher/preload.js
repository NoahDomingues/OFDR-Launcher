const { contextBridge, ipcRenderer } = require('electron');
const path = require('path');
const fs = require('fs');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld(
  'api', {
    saveGamePath: (gamePath) => {
      ipcRenderer.send('save-game-path', gamePath);
    },
    
    getGamePath: () => {
      return ipcRenderer.sendSync('get-game-path');
    },
    
    launchGame: (gamePath) => {
      ipcRenderer.send('launch-game', gamePath);
    },
    
    launchMissionEditor: (gamePath) => {
      ipcRenderer.send('launch-mission-editor', gamePath);
    },
    
    openModsFolder: (gamePath) => {
      ipcRenderer.send('open-mods-folder', gamePath);
    },
    
    listDirectories: async (directoryPath) => {
      try {
        const result = await ipcRenderer.invoke('list-directories', directoryPath);
        return result;
      } catch (error) {
        console.error('Error listing directories:', error);
        return [];
      }
    },
    
    installMod: async (gamePath, modBuffer, fileName) => {
      try {
        return await ipcRenderer.invoke('install-mod', gamePath, modBuffer, fileName);
      } catch (error) {
        console.error('Error installing mod:', error);
        throw error;
      }
    },
    
    uninstallMod: async (gamePath, modName) => {
      try {
        return await ipcRenderer.invoke('uninstall-mod', gamePath, modName);
      } catch (error) {
        console.error('Error uninstalling mod:', error);
        throw error;
      }
    },
    
    listInstalledMods: async (gamePath) => {
      try {
        return await ipcRenderer.invoke('list-installed-mods', gamePath);
      } catch (error) {
        console.error('Error listing installed mods:', error);
        return [];
      }
    }
  }
);
